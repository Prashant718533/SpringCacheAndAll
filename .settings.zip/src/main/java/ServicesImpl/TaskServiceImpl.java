package ServicesImpl;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import Dto.TaskDTO;
@Service
public class TaskServiceImpl {
//    private final Logger logger = LoggerFactory.getLogger(getClass());
//
//    public List<TaskDTO> findAll() {
//        logger.info("Retrieving tasks");
//        return Arrays.asList(new TaskDTO(1L, "My first task", true), new TaskDTO(2L, "My second task", false));
//    }
}